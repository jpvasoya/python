#text analyzer-1
text=input("enter file name")
with open(text) as t1:
	f=t1.read()
print(f)