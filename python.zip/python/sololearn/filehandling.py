#try:
#    a=["i[i]",i*i for i in range(10)]
#    print(a)
#except SyntaxError:
#	print("Plz Check your code")
#finally:
#	print("its always work")
#memory Error
#list=[2*i for i in range(10**100)]
#print(list)
#string formating
a=[1,2,3]
str={"no:{0},{1}".format(a[0],a[2],a[0])}
print(str)