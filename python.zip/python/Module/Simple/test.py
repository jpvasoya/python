#try.py
def add(a,b):
	sum=a+b
	return sum