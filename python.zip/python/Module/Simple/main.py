#main.py
import test
x=test.add(5,10)
print("add=",x)