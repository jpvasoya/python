import math
N = int(input())
#your code goes here
for i in range(0,N+1):
  print(sum(i))