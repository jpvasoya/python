#trignometry function
import math
print("cos:",math.cos(0))
print("sin:",math.sin(90))
print("tan:",math.tan(0))

