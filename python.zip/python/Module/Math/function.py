import math
a=3.14
print("ceil:",math.ceil(a))
print("floor:",math.floor(a))
print("exp:",math.exp(11))
b=9
print("sqrt:",math.sqrt(b))
print("log:",math.log(10,10))
print('pow:',math.pow(2,3))

	
	