#constant
import math
print(math.pi)#π
print(math.e)#e
