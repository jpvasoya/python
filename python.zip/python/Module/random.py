import random
print(random.random())