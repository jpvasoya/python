#m.py
def add(a, b):
	print("addition:",a+b)
def mul(a, b):
	print("multiplication:",a*b)
def sub(a, b):
	print("substraction:",a-b)
def div(a, b):
	print("division:",a/b)