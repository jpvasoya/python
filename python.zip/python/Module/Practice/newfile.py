#from... import statement
from m import add
print(add(2,3))