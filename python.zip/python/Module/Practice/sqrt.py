import math
print(math.sqrt(9))