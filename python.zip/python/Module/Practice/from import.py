#from... import statement
from m import add
print(add(2,3))#only add fun inclusive 
#print(sub(3,2))
from m import*
print(sub(3,2))
print(mul(3,2))#its not good  because more duplication
print(div(1,2))