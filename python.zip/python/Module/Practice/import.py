#import statement
import m
a=float(input('enter 1st value:'))
b=float(input('enter 2nd value:'))
m.add(a, b)
m.sub(a, b)
m.mul(a, b)
m.div(a, b)