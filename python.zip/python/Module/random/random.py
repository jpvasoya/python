#random module
import random
[]