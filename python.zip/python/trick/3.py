#trick 3
def add(f,s):
	return f+s
#print(add(1,5))
import pdb
pdb.set_trace()
#add(1,'two')