#trick 1
x,y=input("enter name:").split()
print(x)
print(y)