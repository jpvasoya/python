def add(x,y):
	add=x+y;
	return add;
def sub(x,y):
	sub=x-y;
	return sub;
def mul(x,y):
	mul=x*y;
	return mul;
def div(x,y):
	div=x/y;
	return div;
#print(add(5,2));
input
switch(n):
	{
	case 1:print("")