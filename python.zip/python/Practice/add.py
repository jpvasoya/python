#add
def add():
      a=float(input("enter value:"))
      b=float(input("enter value:"))
      print('add value:',a+b)
add()