#iterative control statement
#1.for loop
for j in range(1, 6):
	print(j)
print ('\n')
for i in range (1, 6):
	for j in range(i):
		print(i ,end=' ')
	print(' ')
print ('\n')
#2.while loop
i=1
while i <6:
	print(i)
	i+=1
print ('\n')

