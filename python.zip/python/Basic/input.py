#input and output
#1.print() 
print("I'm python")
print('how can I help you🤨🧐')#print
print("------------------------------------")
#input()
a=input("enter value:")#by keyboard input
print(a)