#comment
#multi
#line
#comment
"""
hello 
world
why i'm not seen in
output
"""
print('done')