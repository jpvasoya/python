num=int(input("enter a number:"))
if num>0:
	print("Positive number and\n type of the value is")
	print(type(num))
elif num==0:
	print("its zer0")
else:
	print("Nagetive number")