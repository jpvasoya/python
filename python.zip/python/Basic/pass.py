for n in range(1,6):
	if(n>=2):
		pass
	print(n)
 