#break and continue
print('break')
for j in range(1,6):
	if(j==4):#stop
		break
	print(j)
print('\n')
print ('continue')
for j in range(1,6):
	if(j==4):#skip
		continue
	print(j)

