'bitwise operator'
x=1#0001
y=2#0010
print(x&y)# and
print(x|y)#or
print(x^y)#xor
print(~x)#not
print(x>>y)#right shift
print(x<<y)#left