'membership operator'
x="jaydip vasoya"
print('J' in x)
print('y' in x)
print('😅😂' not in x)