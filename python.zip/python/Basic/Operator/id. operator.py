"identity operator"
x=1
y=2
print(x is y,"\t",x is not y)