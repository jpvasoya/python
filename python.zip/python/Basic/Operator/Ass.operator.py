"assignment operator"
a=1
b=2
b+=a#b=b+a
a+=b
print(b," ",a)
