#arithmatic operator
a=5
b=2
print(a+b)#  + operator
print(a-b)  #   - operator
print(a*b)# * operator
print(a/b)# / operator
print(a%b)# reminder
print(a//b)#floor 
print(a**b)#power of 