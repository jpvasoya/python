'logical operator'
x=1
y=False
print(x and y)
print(x or y)
print(not x)
print(x or y)