
#simple class
class jp:
	name='jp vasoya'
	print(name)
print(jp.name)