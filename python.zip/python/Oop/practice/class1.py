class hello:
	print('hello')
	a+b
