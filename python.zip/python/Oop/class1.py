class computer:
	def config(self):
		print("its config file in computer class")

com1=computer()	
#computer.cofig(com1)
com1.config()