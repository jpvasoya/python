import numpy as np
a=np.linspace(4,5,8).reshape(2,2,2)#5 time number between 4 to 5
print(a)
print("\n")
b=np.arange(4,10)
print(b)