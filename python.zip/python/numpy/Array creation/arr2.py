import numpy as np
a=np.array([(1,2,3),(3,4,5)]).reshape(6,1,1)
print(a)
b=np.arange(20).reshape(2,5,2)
print(b)
c=np.array([(1,2,3),(4,5,6),(7,8,9)], dtype=float)
print(c)
