import numpy as np
a=np.zeros((5,5),dtype=np.int64)
print(a)
b=np.ones((4,4),dtype=int)
print(b)
c=np.empty((2,3))
print(c)
d=np.arange(2, 5, 0.5)
print(d)
