def prime(n):
	if n%2==0:
		print("its Even no",n)
	else:
		print("its odd no",n)
n=int(input("enter no:"))
prime(n)