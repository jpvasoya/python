#keyword arguments
def rem(div, did):
	r=div%did
	return r
r=rem(did=3,div=10)#keyword arguments
r1=rem(10,3)
print("reminder:",r)
print("reminder:",r1)
