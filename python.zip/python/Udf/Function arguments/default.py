#default arguments
def data(name, age, profession="self"):
	print("name:",name)
	print("age:",age)
	print("profession:",profession)
	return
data("jp vasoya",20,"Anonymous")
print("------------------------------------")
data('kapil Sorathiya',21)
print("------------------------------------")
data("kartik babariya",19)
print("------------------------------------")
data("rahul vaghela",19)
print("------------------------------------")