#required arguments
def cube(x):
	c=x*x*x
	return c
cube=cube(4)#required arguments
print('cube:',cube)