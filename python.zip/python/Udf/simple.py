#simple
def jp():#keyword def
	print("my name is jp vasoya")
jp();
jp();#call two times