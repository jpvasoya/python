#return statement
def sum(a, b):
	s=a+b
	return s#give value in the calling time function
a=float(input('enter a:'))
b=float(input('enter b:'))
sum=sum(a, b)
print('sum:',sum)
