#arguments
def evenOdd(n):#formal argument
      if(n%2==0):
      	print("even no")
      else:
      	print("odd no")
a=int(input("enter no:"))
evenOdd(a)#actual argument
