#change directories
import os
os.chdir('//storage/emulated/0/python/file handling')
print(os.getcwd())