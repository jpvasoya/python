#1.getcwd()method to get current working directories
import os
print(os.getcwd())