#remove directories
import os
os.rmdir("//storage/emulated/0/python/file handling/try")