#create directories
import os
os.mkdir('directories')