#opening file
obj=open("jp.txt",'r')#default access mode read only
#print('my name is jp')
obj=open("jp.txt","wb")