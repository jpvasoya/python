#write data 
obj=open("jp.txt",'w')
obj.write('hello\n')
obj.write('my name is jp\n')
obj.write("------------------------------------")
print('done')
obj.close()