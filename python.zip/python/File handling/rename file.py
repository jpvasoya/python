#rename file
import os
os.rename('jay.txt','jp.txt')
#remove file
#os.remove('jp.txt')