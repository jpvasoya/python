#function 2
#len()
list1 = ['a','b','c']
print(len(list1))#lenght of the list
#list(seq)
str='jp vasoya'
l=list(str)#convert seq to list
print(l)
j="123456"
l1=list(j)
print(l1)
t=('jp',1,2)
l=list(t)
print(l)