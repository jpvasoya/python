#list function
l=[5,3,99,2]
l1=[5,3,99,2,'1']
l2=['A','b']
#min
print(min(l))
#print(min(l1))#not supported 
print(min(l2))
list1 = ['a','b','c']#in this list one type of orderable
print(min(list1))
#max
print(max(l))
print(max(l2))
#print(max(l1)) not supported
