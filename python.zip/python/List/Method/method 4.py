#method 4
#sort
l=[5,3,99,2]
l. sort()#list  object type are same
print(l)
#2.reverse
l. reverse()
print(l)
#using slice operator
print(l[::-1])