#method 2
#1.count
print("\n1.count")
l=[5,3,99,2,99,99]
print(l. count(2))
print(l.count(99))#count how many times object occurred
print("\n2.index")
#2.index
print (l.index(3))#find index of the obj
print(l.index(99))#lower index

