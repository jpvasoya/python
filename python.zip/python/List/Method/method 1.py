#method of the list
#append
l= ['a','b','c']
l.append(1)
l.append([2,3,4])#append obj to list
print(l)
#extend
l.extend([5])
l.extend([6,7,8])#append seq to list
l. extend(["jp"])
print(l)
#insert
l.insert(0,"jay")#insert specific location
# obj to list
print(l)
#copy()
l1=l.copy()
print(l1)