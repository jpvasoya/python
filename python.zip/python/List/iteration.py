#iteration of the list
l=[1, 'hello',2,3,4,"jay","vasoya"]
for l1 in range(len(l)):
	print(l[l1])