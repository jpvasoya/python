lst=[1,2,3,4,"heyy"]
print(lst[::-1])