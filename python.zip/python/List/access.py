#list access
l=[1, 'hello',2,3,4,"jay","vasoya"]
#using slice operator
print(l[5])
print(l[2:5])
print(l[: :-1])
print(l[0:5:2])