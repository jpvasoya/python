#list operation 1
#1.adding list
l=[1, 'hello',2,3,4,"jay","vasoya"]
l1=["no",2,3,4]
print(l1+l)
#print(l1+'a') not allowed
#2.replication list
print(2*l1)