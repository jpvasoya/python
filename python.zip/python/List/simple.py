#list ex simple
l=[1, 'hello',2,3,4,"jay","vasoya"]
print(l)#list same as Datastructure