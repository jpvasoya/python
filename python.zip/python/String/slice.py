
s="jay vasoya"
print(len(s))
print(s[4:10])
print(s[-10:-7])
print(s[-1: :-1]) #reversed all string
print(s[0: 10: 2]) #step = 2
print(s[ : : -1]) #reversed all string
print(s[ : 3]) #from 0 to 2
print(s[4 : ]) #from 4 to end of the string
print(s[ : ]) #copy all strin