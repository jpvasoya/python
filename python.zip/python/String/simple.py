#1.simple
s1='jp'#single quote
s2="vasoya"#double quote
print(s1+" "+s2)