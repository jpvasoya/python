#1.basic operator
#1.concatenation operator +
s1=" jp"
s2='vasoya'
print(s1+' '+s2)
print("\n")
#2.replication operator
print(3*s1)