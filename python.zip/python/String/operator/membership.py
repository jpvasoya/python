#2.membership operator
s1='jaydip vasoya'
s2="jp vasoya"
s3='jp'
s4='vasoya'
print('in')
print (s2 in s1)
print('Jay' in s1)
print('jay' in s1)
print(s4 in s1)
print('\nnot in')
print(s3 not in s1)