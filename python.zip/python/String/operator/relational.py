#3.relational operator
print("a"!='A')
print ('Jay'<='jay')