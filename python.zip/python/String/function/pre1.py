#predefined function 1
#1.capitalize()
s="jp Vasoya"
print(s.capitalize())#first char capital
#2.lower()
print(s.lower())#convert lower
#3.upper()
print (s.upper())
#4.swapcase()
print(s.swapcase())