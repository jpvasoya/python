#simple function
def jp():#user define
	print('jay vasoya')
jp() 