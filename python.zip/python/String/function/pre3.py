#predifined function 3
#1.len()
s="Jaydip vasoya"
print (len(s))#find string length 
#2.max()
print (max(s))#find max char in string
                    #ascii value depends
 #3.min()
print(min(s))#output space
s1="Jp"
print (min(s1))