s="jp vasoya"
p=-1
for a in range(len(s)):
	print(s[a],'\t',s[p])
	a+=1
	p-=1