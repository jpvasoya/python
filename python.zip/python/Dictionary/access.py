#simple
d={1:'jp', 'king':'vasoya',1:'jay'}
print (d)
print(d['king'])#access by key
print(d[1])#key unique