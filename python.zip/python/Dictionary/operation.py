#updating dictionary
d={1:'jp', 'king':'vasoya',3:'where', 4:'are'}
d[1]='jay'
print(d)
#insert new value
d[5]='jp'
print(d)
#deleting dictionary
del(d[3])#by delete specific elements
print(d)
d.clear()#clear all entries
print(d)
del(d)#whole dictionary deletee
print(d)