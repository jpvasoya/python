#function
#1.len()
d={1:'jp', 'king':'vasoya',3:'where', 4:'are'}
print(len(d))#length
#2.str()
print(str(d))#just used in represention of the string form
#3.type
print(type(d))#get type
#ex2
l=[1,2,3]
print(type(l))