#method 4
#1.values()
d={1:'jp', 'king':'vasoya',3:'where', 4:'are'}
print(d.values())#get values
#2.items()
print(d.items())#return tuples pairs all of the keys and values
#3.keys()
print(d.keys())#get keys
