#method 2
#1.fromkeys(seq, values)
d={1, 2,3,4}
dict=dict.fromkeys(d,"jay")#set values in dictionary
print(dict)#by default none
