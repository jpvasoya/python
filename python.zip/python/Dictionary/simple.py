#simple
d={1:'jp', 'king':'vasoya'}
print (d)
print(d['king'])
