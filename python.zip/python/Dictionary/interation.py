#interation
d={1:'jp', 'king':'vasoya',2:'jay',3:'done'}
#print(d.keys())
for n in d.keys():
	print(d[n])