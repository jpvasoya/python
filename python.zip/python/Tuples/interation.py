#interation of the tuples
t=(2,99,3,1,'jay')
for n in range(len(t)):
	print(t[n])
