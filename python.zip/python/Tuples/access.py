#accessing tuples
t=(1,3,4,99,'jay',2)
#using slice operator
print(t[0])
print(t[0:2])
print(t[0:6:2])
print(t[::-1])