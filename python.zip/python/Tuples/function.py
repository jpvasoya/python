#function
#min
t=(2,99,3,1)
print(min(t))
#max
print(max(t))
#len
print(len(t))
#tuple(seq)
#convert to tuples
s='02_jp_vasoya'
t=tuple(s)
print(t)