#simple
#same as list but here not updating any obj of the tuples
#used in parentheses
t=('jay',1,2,3)
print(t)
t=1, 2,3,4,'jp'#also we write
print(t)
